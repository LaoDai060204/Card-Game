43 RGBA PNG standees: 41 new AI-derived review silhouettes plus two unchanged earlier samples.
Use cutouts/<CardID>.png. Real alpha; checkerboards are not baked in.
See cutouts.json for source references, hashes, dimensions and alpha bounds.
These are 2.5D images, not volumetric meshes or pixel-exact masks.
Ritenia is an unchanged user-supplied crop with small background remnants.
Battle Spirits illustrations: BNP/BANDAI; original credits are retained in the referenced card images.
