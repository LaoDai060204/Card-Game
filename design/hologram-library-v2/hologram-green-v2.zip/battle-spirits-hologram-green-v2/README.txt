Battle Spirits — Green hologram review v2

Extract the entire ZIP, then open index.html in Chrome or Edge.
No CDN or web server required: all runtime scripts and image payloads are included.
Search by name/card ID, filter color/type, select a Spirit to inspect its hologram.
Green: 9 Spirit standees, plus same-color Nexus/Magic and the two earlier Ritenia/Pisketona samples.
Ritenia is the only assigned demonstration boss; other new Spirits use a short local reveal.
All resources and phase buttons are illustrative; this is not a game/rules engine. No Unity code changes.
PNG assets for project integration are available separately in spirit-cutouts-43.zip on the review branch.
Battle Spirits © BNP/BANDAI; unofficial review. Three.js MIT license is included in vendor.
